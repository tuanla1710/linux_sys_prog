#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>


int main(int argc, char *argv[]){
	
	if(argc != 2){
		fprintf(stderr, "Usage: %s <pid no>\n", argv[0]);
		exit(1);
	}
	
	for(int i=1; i<=64; i++){
		if(i==9 || i==32 || i==33)
			continue;
		if(i==18){
			kill(atoi(argv[1]), 19);
			sleep(2);
			continue;
		}
		if(i==19){
			kill(atoi(argv[1]), 18);
			sleep(2);
			continue;
		}
			
		if((kill(atoi(argv[1]), i)) == -1){
			if(errno == EINVAL){
				printf("Invalid signal\n");
			}else if(errno == EPERM){
				printf("No Permission\n");
			}else if(errno == ESRCH){
				printf("No such process\n");
			}
		}
		sleep(1);
	}
	
		
	return 0;
}