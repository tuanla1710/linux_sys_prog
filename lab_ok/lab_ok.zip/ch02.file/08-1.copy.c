#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]){
	
	// char *buf;
	char buf[4096];
	int fd1, fd2, i;
	int numByte;
	
	if(argc != 3) {
		printf("Usage: %s <source filename> <destination filename>\n", argv[0]);
		exit(1);
	}
	
	if((fd1 = open(argv[1], O_RDONLY)) == -1){
		perror("file open1 error");
		exit(2);
	}
	
	if((fd2 = open(argv[2], O_WRONLY|O_CREAT, S_IRWXU|S_IRWXG|S_IRWXO)) == -1){
		perror("file open2 error");
		close(fd1);
		exit(2);
	}
	
	
	// if((buf = (char *)malloc(filesize)) == NULL){
		// perror("malloc");
		// close(fd1);
		// close(fd2);
		// exit(2);
	// }
	
	while((numByte = read(fd1, buf, 4096)) > 0){
		if (write(fd2, buf, numByte) != numByte) {
			perror("file read error");
			close(fd1);
			close(fd2);
			exit(3);
		}
	}
	
	// if(write(fd2, buf, filesize) == -1) {
		// perror("filw write error");
		// close(fd2);
		// close(fd1);
		// exit(3);
	// }
		
	close(fd1);
	close(fd2);
	return 0;
}
