#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
	int i;
	pid_t pid, ppid;
	
	pid=getpid();
	ppid=getppid();
	printf("PID=%d\n", pid);
	printf("PPID=%d\n", ppid); 
	
	execl("./01.mytask","01.mytask","100");
	return 0;
}