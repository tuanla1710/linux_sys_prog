#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
	pid_t pid;
	int status;
	
	pid=fork();
	
	if(pid == 0){		//child
		printf("\tCHILD PROCESS --- (%d)\n", getpid());
		sleep(3);
		system("ps -l");
		printf("-----------------------\n");
		// execl("./01.mytask","01.mytask","100");
		
	} else {			//parent
		printf("PARENT PROCESS --- (%d)\n", getpid());
		pid=wait(&status);
		sleep(5);
		// pid=wait(&status);
		system("ps -l");
	}
	
	return 0;
}