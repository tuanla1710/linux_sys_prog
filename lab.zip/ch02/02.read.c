#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]){
	
	int fd, fd2;
	size_t ret;
	char buf[512];
	 // ssize_t read(int fd, void *buf, size_t count);
	if(argc < 3){
		fprintf(stderr, "Usage : %s <src> <dst>\n", argv[0]);
		exit(0);
	}
	fd=open(argv[1], O_RDONLY );
	
	ret=read(fd, &buf, sizeof(buf));
	if(ret == -1){
		perror("read");
		close(fd);
		exit(1);
	}
	
	// printf("%s", buf);
	fd2=open(argv[2], O_WRONLY);
	write(fd2,&buf, strlen(buf));
	
	close(fd);
	close(fd2);
	return 0;
}
