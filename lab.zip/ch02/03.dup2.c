#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]){
	int fd;
	char data[]="Hello world\n";
	
	fd=open(argv[1], O_WRONLY | O_APPEND | O_CREAT, 0666);
	dup2(fd, 1);
	close(fd);
	
	write(1, data, sizeof(data));
	for(;;){}
	return 0;
}