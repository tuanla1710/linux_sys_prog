#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]){
	int fd;
	size_t ret;
	char buf[]="Welcome to System Programming\n";
	// int open(const char *pathname, int flags, mode_t mode);

	
	fd=open(argv[1], O_WRONLY | O_CREAT | O_APPEND, 0666);
	if(fd == -1){
		perror("open");
		exit(1);
	}
	
	// printf("FD = %d\n", fd);
	 // ssize_t write(int fd, const void *buf, size_t count);
	ret=write(fd,&buf, strlen(buf));
	if(ret == -1){
		perror("write");
		close(fd);
		exit(1);
	}
	printf("RET=%ld\n", ret);
	
	close(fd);
	return 0;
}