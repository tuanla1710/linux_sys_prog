#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

int main(){
	
	sigset_t set1, set2;
	
	sigemptyset(&set1);
	sigaddset(&set1, SIGINT);
	
	sigfillset(&set2);
	sigdelset(&set2, SIGINT);
	
	sigprocmask(SIG_SETMASK, &set1, NULL);
	
	for(int i=0;;i++){
		printf("looping ---- %d\n", i);
		// pause();
		sleep(1);
		if(i>10){
			sigprocmask(SIG_BLOCK, &set2, NULL);
		}
		// kill(getpid(), 9);
		// raise(2);
	}
	return 0;
}