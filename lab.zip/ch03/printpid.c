#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>


int main(){
	FILE *fp;
	char pidof[128];
	pid_t pid;
	
	fp=popen("pidof a.out", "r");
	fgets(pidof, 128, fp);
	pid=atoi(pidof);
	printf("PID=%d\n", pid);
	kill(pid, 38);
	return 0;
}