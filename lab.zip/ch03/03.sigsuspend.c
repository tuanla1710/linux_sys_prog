#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "signalprint.h"

void handler(int signo){
	printf("Signal caught --- %d\n", signo);
}

int main(){
	sigset_t set1, set2, pendingset;
	
	signal(38, handler);
	sigfillset(&set1);
	sigfillset(&set2);
	sigdelset(&set2, 38);
	
	sigprocmask(SIG_BLOCK, &set1, NULL);
	
	printf("Critical Region 1 begin\n");
	sleep(5);
	printf("Critical Region 1 end\n");
	
	// sigsuspend(&set2);
	// pause();
	
	sigpending(&pendingset);
	print_sigset_t(&set1);
	print_sigset_t(&pendingset);
	if(!sigismember(&pendingset, 38)){
		sigsuspend(&set2);
		// sigpromask(SIG_SETMASK, &set2, NULL);
		// pause();
	}
	
	printf("Critical set2Region 2 begin\n");
	sleep(5);
	printf("Critical Region 2 end\n");
	return 0;
}