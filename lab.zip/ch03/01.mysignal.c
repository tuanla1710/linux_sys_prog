#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void my_handler(int signo){
	printf("signal caught -- %d\n", signo);
	if(signo == 15){
		printf("I don't want to die\n");
		exit(3);
	}
}

int main(){
	int i;
	
	// sighandler_t signal(int signum, sighandler_t handler);
	// typedef void (*sighandler_t)(int);
	signal(2, my_handler);
	signal(SIGQUIT, my_handler);
	signal(15, my_handler);
	
	
	for(i=0;;i++){
		printf("looping ---- %d\n", i);
		// pause();
		sleep(1);
		// kill(getpid(), 9);
		raise(2);
	}
	return 0;
}