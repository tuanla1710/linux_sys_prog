#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]){
	int i;
	if(argc < 2){
		printf("Usage : %s <number>\n", argv[0]);
		exit(2);
	}
	for(i=0; i<atoi(argv[1]); i++){
		printf("looping ---- %d\n", i);
		sleep(1);
	}
	return 0;
}